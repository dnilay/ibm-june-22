package com.crudapp;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
